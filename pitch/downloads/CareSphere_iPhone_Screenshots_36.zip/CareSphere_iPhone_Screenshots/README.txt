CareSphere — iPhone-framed screenshot collection

36 numbered PNGs, 1370 x 2880 pixels, transparent backgrounds.
00-Visual-Index.jpg lets you browse the whole collection.

These are genuine screenshots of the running CareSphere React web app
at a 390 x 844 mobile viewport, captured at 3x resolution. They are NOT
native SwiftUI/iOS screenshots. The iPhone-style device frame, status
bar and home indicator were drawn in Python, outside the app capture.
No AI-generated imagery or fabricated app screens were used.

Names, medications, notes and mood history are fictional sample data.
Vital readings in screenshots 26–27 are explicitly simulated, not sensor
measurements. SOS is shown without placing calls. No video meeting was
joined. No real patient information is included.

Coverage: overview, mood, routines, medications, activities, breathing,
soundscapes, feelings, pattern recall, pairs, story, Coffee Circles,
care notes, local summary, visit brief, vitals, settings, SOS, light
appearance and high contrast.

Manifest.json records source-capture SHA-256 hashes for provenance.
Project: https://github.com/engineer2025-sudo/Care
